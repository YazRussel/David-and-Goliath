import java.awt.*;

// Responsible to be overwritten by the subclass
public interface Drawable {
    void draw(Graphics g);


}
