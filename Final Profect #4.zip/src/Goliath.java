import javax.swing.*;

public class Goliath extends Sprite{
    //A constructor to find the location of the picture and get the image
    public Goliath(){
        super();
        this.image = new ImageIcon("C:\\Users\\Yaz Russel\\IdeaProjects\\Project\\src\\malaki.png");
    }
}

