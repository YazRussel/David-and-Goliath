
import javax.swing.*;
import java.awt.Graphics;
import java.awt.Color;
import java.util.ArrayList;

public class Main extends JPanel {
    //Enter an expandable array
    private ArrayList<Room> rooms = new ArrayList<>();

    public Main() {
        //To have 5x5 boxes
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                // Spacing rooms 60 pixels apart
                rooms.add(new Room(10 + j * 60, 10 + i * 60));
            }
        }
        //Make a passageway
        rooms.get(0).setEastExit(rooms.get(1));
        rooms.get(0).setSouthExit(rooms.get(5));
        rooms.get(1).setEastExit(rooms.get(2));
        rooms.get(2).setEastExit(rooms.get(3));
        rooms.get(4).setSouthExit(rooms.get(9));
        rooms.get(5).setEastExit(rooms.get(6));
        rooms.get(7).setSouthExit(rooms.get(12));
        rooms.get(8).setEastExit(rooms.get(9));
        rooms.get(8).setSouthExit(rooms.get(13));
        rooms.get(10).setEastExit(rooms.get(11));
        rooms.get(10).setSouthExit(rooms.get(15));
        rooms.get(12).setSouthExit(rooms.get(17));
        rooms.get(14).setWestExit(rooms.get(13));
        rooms.get(15).setSouthExit(rooms.get(20));
        rooms.get(16).setSouthExit(rooms.get(21));
        rooms.get(16).setEastExit(rooms.get(17));
        rooms.get(17).setEastExit(rooms.get(18));
        rooms.get(17).setSouthExit(rooms.get(22));
        rooms.get(18).setEastExit(rooms.get(19));
        rooms.get(22).setEastExit(rooms.get(23));
        rooms.get(23).setEastExit(rooms.get(24));

    }
    @Override
    protected void paintComponent(Graphics g) {
        //Draw the rooms
        super.paintComponent(g);
        for (Room room : rooms) {
            room.draw(g);
        }
    }
    //Pop up a window to show the Maze
    public static void main(String[] args) {
        JFrame window = new JFrame("Maze Runner");
        Main main = new Main();
        window.add(main);
        window.setSize(400,400);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        window.setBackground(Color.LIGHT_GRAY);
    }
}
