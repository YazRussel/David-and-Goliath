import java.awt.*;
public class Room {
    private Point pos;
    private Room exitEast, exitWest, exitNorth, exitSouth;
    //Constructor and Initializes the Room object
    public Room(int x, int y) {
        //Represent the position of the room
        this.pos = new Point(x, y);
        //Represent the exit of the room
        this.exitEast = null;
        this.exitWest = null;
        this.exitNorth = null;
        this.exitSouth = null;
    }

    //When it exits to the East, the West side will also give an entrance
    public void setEastExit(Room r) {
        this.exitEast = r;
        r.exitWest = this;
    }
    //When it exits to the North, the South side will also give an entrance
    public void setNorthExit(Room r) {
        this.exitNorth = r;
        r.exitSouth = this;
    }
    //When it exits to the West, the East side will give an entrance
    public void setWestExit(Room r) {
        this.exitWest = r;
        r.exitEast = this;
    }
    //When it exits to the South, the North side will give an entrance
    public void setSouthExit(Room r) {
        this.exitSouth = r;
        r.exitNorth = this;
    }


    public void draw(Graphics g){
        int wallSize = 50;
        int doorWidth = 20;
        // North wall, when the code did not touch this, the wall will remain the same
        //Or else it will make a passageway
        if (exitNorth == null) {
            g.drawLine(pos.x, pos.y, pos.x + wallSize, pos.y);
        } else {
            g.drawLine(pos.x, pos.y, pos.x + doorWidth, pos.y);
            g.drawLine(pos.x + wallSize - doorWidth, pos.y, pos.x + wallSize, pos.y);
        }

        // East wall,when the code did not touch this, the wall will remain the same
        //Or else it will make a passageway
        if (exitEast == null) {
            g.drawLine(pos.x + wallSize, pos.y, pos.x + wallSize, pos.y + wallSize);
        } else {
            g.drawLine(pos.x + wallSize, pos.y, pos.x + wallSize, pos.y + doorWidth);
            g.drawLine(pos.x + wallSize, pos.y + wallSize - doorWidth, pos.x + wallSize, pos.y + wallSize);
        }

        // South wall,when the code did not touch this, the wall will remain the same
        //Or else it will make a passageway
        if (exitSouth == null) {
            g.drawLine(pos.x, pos.y + wallSize, pos.x + wallSize, pos.y + wallSize);
        } else {
            g.drawLine(pos.x, pos.y + wallSize, pos.x + doorWidth, pos.y + wallSize);
            g.drawLine(pos.x + wallSize - doorWidth, pos.y + wallSize, pos.x + wallSize, pos.y + wallSize);
        }
        // West wall,when the code did not touch this, the wall will remain the same
        //Or else it will make a passageway
        if (exitWest == null) {
            g.drawLine(pos.x, pos.y, pos.x, pos.y + wallSize);
        } else {
            g.drawLine(pos.x, pos.y, pos.x, pos.y + doorWidth);
            g.drawLine(pos.x, pos.y + wallSize - doorWidth, pos.x, pos.y + wallSize);
        }
    }
}


